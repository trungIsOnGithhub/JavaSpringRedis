import axios from 'axios';
axios.defaults.withCredentials = true;

const BASE_URL = 'http://localhost:8080';

export const MESSAGES_TO_LOAD = 10;

function url(path) { return `${BASE_URL}${path}`; }

/** Checks if there's an existing session. */
export const getMe = () => {
  return axios.get(url('/users/me'))
    .then(x => x.data)
    .catch(_ => null);
};

/** 
 * Fetch users by requested ids
 * @param {Array<number | string>} ids
 */
export const getUsers = (ids) => {
  return axios.get(url(`/users`), { params: { ids: ids.reduce((x, y) => `${x},${y}`) } }).then(x => x.data);
};

/** Fetch users which are online */
export const getOnlineUsers = () => {
  return axios.get(url(`/users/online`)).then(x => { console.log(x.data); return x.data; });
};

/** Handle user log in */
export const login = (username, password) => {
  if (password !== "password123") {
    throw new Error("Wrong Password");
  }

  switch(username) {
    case "User1":
      return { id: 1, username: "User1", isOnline: true };
    case "User2":
      return { id: 2, username: "User2", isOnline: true };
    case "User3":
      return { id: 3, username: "User3", isOnline: true };
    case "User4":
      return { id: 4, username: "User4", isOnline: true };
    default:
      throw new Error("Wrong Username");
  }
  // return axios.post(url('/auth/login'), {
  //   username,
  //   password
  // }).then(x =>
  //   { console.log(x.data); return x.data; }
  // )
  //   .catch(e => { throw new Error(e.response && e.response.data && e.response.data.message); });
};

export const logOut = () => {
  // return axios.post(url('/auth/logout'));
};

// /** 
//  * Function for checking which deployment urls exist.
//  * 
//  * @returns {Promise<{
//  *   heroku?: string;
//  *   google_cloud?: string;
//  *   vercel?: string;
//  *   github?: string;
//  * }>} 
//  */
// export const getButtonLinks = () => {
//   return axios.get(url('/links'))
//     .then(x => x.data)
//     .catch(_ => null);
// };
// 
// [{id:"1:2",names:["User1","User2"]},{id:"1:3",names:["User1","User3"]},{id:"1:4",names:["User1","User4"]},{id:"0",names:["General"]}]
// 
// 

/** 
 * @returns {Promise<Array<{ names: string[]; id: string }>>} 
 */
export const getRooms = (userId) => {
  console.log(typeof userId);
  switch(userId) {
    case 2:
      return [{id:"2:3",names:["User2","User3"]},{id:"1:2",names:["User1","User2"]},{id:"2:4",names:["User2","User4"]},{id:"0",names:["General"]}];
    case 1:
      return [{id:"1:2",names:["User1","User2"]},{id:"1:3",names:["User1","User3"]},{id:"1:4",names:["User1","User4"]},{id:"0",names:["General"]}];
    case 3:
      return [{id:"3:4",names:["User3","User4"]},{id:"2:4",names:["User2","User4"]},{id:"1:4",names:["User1","User4"]},{id:"0",names:["General"]}];
    case 4:
      return { id: 4, username: "User4", isOnline: true };
    default:
      throw new Error("Wrong UserID");
  }
  // return axios.get(url(`/rooms/user/${userId}`)).then(x => { console.log(JSON.stringify(x.data)); return x.data; });
};

getRooms(4);

/**
 * Load messages
 * 
 * @param {string} id room id
 * @param {number} offset 
 * @param {number} size 
 */
export const getMessages = (id,
  offset = 0,
  size = MESSAGES_TO_LOAD
) => {
  // console.log(id);
  console.log("+++" + typeof id)
  console.log("|||"+id+"|||");
  // [{"from":"1","date":1700127951,"message":"isld a dsjadlkjsada dlisajdl","roomId":"0"},{"from":"1","date":1700127958,"message":"jslks;dsada","roomId":"0"}] api.js:130

  
  if (id === "0" ) {
    return [{"from":"4","date":1697093948,"message":"JCAPOSKC*(8)","roomId":"0"},{"from":"1","date":1697094148,"message":"1 + 1 = 3","roomId":"0"},{"from":"1","date":1697094348,"message":"Chao ban??","roomId":"0"},{"from":"3","date":1697094548,"message":"Tam biet","roomId":"0"},{"from":"4","date":1700123793,"message":"dasdsa","roomId":"0"},{"from":"1","date":1700127946,"message":"jieuoiufo;sjdo","roomId":"0"},{"from":"1","date":1700127951,"message":"isld a dsjadlkjsada dlisajdl","roomId":"0"},{"from":"1","date":1700127958,"message":"jslks;dsada","roomId":"0"}]
  }
  if (id === "1:4" ) {
    return  [{"from":"4","date":1697094704,"message":"Day La mot tin nhan","roomId":"1:4"},{"from":"1","date":1697094746,"message":"($)@!)#)_+)+!3","roomId":"1:4"}];
  }
  if (id === "1:2" ) {
    return [{"from":"2","date":1700126273,"message":"jsladjlsad","roomId":"1:2"},{"from":"2","date":1700126276,"message":"akdlskf;sa\\nkd;lsa","roomId":"1:2"}];
  }
  if (id === "2:3" ) {
    return [{"from":"3","date":1697094544,"message":"Day La mot tin nhan voi emoji 😎","oomId":"2:3"},{"from":"2","date":1697094585,"message":"Hello Friend 🏄🏻🏄🏻🏄🏻","roomId":"2:3"}];
  }
  if (id === "2:4" ) {
    return [{"from":"4","date":1697094685,"message":"Day La mot tin nhan voi ki tu dac biet !2#!$2","roomId":"2:4"},{"from":"2","date":1697094738,"message":"Day La mot tin nhan","roomId":"2:4"}];
  }
  // throw new Error("Wrong RoomID");
  // return axios.get(url(`/rooms/messages/${id}`), {
  //   params: {
  //     offset,
  //     size
  //   }
  // })
  //   .then(x => { console.log(JSON.stringify(x.data.reverse())); return x.data; });
};

/** This one is called on a private messages room created. */
export const addRoom = async (user1, user2) => {
  return axios.post(url(`/room`), { user1, user2 }).then(x => { console.log(x.data); return x.data; });
};

export const emitMessage = (type = "", user, message) => {
  console.log("from api.js &&&&& "+JSON.stringify(user));
  messages[message.roomId].push(message);
};

export const getEventSource = (userId) => new EventSource(url(`/chat/stream?userId=${userId}`));
